package co.com.bancolombia.config;

import co.com.bancolombia.consumer.config.InternalConsumer;
import co.com.bancolombia.secretsmanager.api.GenericManager;
import co.com.bancolombia.secretsmanager.api.exceptions.SecretException;
import co.com.bancolombia.secretsmanager.connector.AWSSecretManagerConnector;
import lombok.AllArgsConstructor;
import lombok.extern.java.Log;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

@Log
@Configuration
@AllArgsConstructor
public class InternalConsumerConfig {


    @Bean
    @Profile("!local")
    public InternalConsumer getClientCredentialsFromSecretManager
            (
                    @Value("${aws.region}") String region,
                    @Value("${aws.secretsManager.secretName}") String secretName) throws SecretException {

        GenericManager connector = new AWSSecretManagerConnector(region);
        return connector.getSecret(secretName, InternalConsumer.class);
    }

    @Bean
    @Profile("local")
    public InternalConsumer getClientCredentialsFromSecretManagerLocal(
            @Value("${service.cerprivate}") String cerprivate,
            @Value("${service.cerpublic}") String cerpublic) throws SecretException {
        return InternalConsumer.builder()
                .cerpublic(cerpublic)
                .cerprivate(cerprivate)
                .build();
    }

}
