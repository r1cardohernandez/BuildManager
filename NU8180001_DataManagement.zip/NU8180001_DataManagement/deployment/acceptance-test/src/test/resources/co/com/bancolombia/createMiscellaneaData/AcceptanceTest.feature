@acceptanceTest
Feature: Escenarios de pruebas de acceptacion para la operación: createMiscellaneaData
  Background:
    * url urlBase
    * def oasUrl = oasUrl
    * configure headers = headers
    * def ValidatorTestUtils = Java.type('co.com.bancolombia.utils.ValidatorTestUtils')
    Scenario: ESCENARIO Crear una nueva miscelanea con datos válidos DADO que el cliente ingreso los datos obligatorios y la llave única del cliente es válida y la llave del sistema fuente es válido CUANDO se invoca la operación de la API ENTONCES el sistema crea la miscelanea del cliente exitosamente en MDM
    Given path '/miscellaneas'
    And request read("creaciónMiscelaneaExitosa.json")
    When method post
    Then status 201
    * string strResponse = response
    * def report = ValidatorTestUtils.validateResponseSchema(oasUrl, strResponse, '/miscellaneas', ValidatorTestUtils.POST, 201)
    * if (report.hasErrors()) karate.fail(report.getMessages() + ' - '+ strResponse)

    Scenario: ESCENARIO Crear una nueva miscelanea con datos válidos DADO que el cliente ingreso los datos obligatorios y la llave única del cliente es válida y la llave del sistema fuente es válido CUANDO se invoca la operación de la API ENTONCES el sistema crea la miscelanea del cliente exitosamente en MDM
    Given path '/miscellaneas'
    And request read("requestExample.json")
    When method post
    Then status 201
    * string strResponse = response
    * def report = ValidatorTestUtils.validateResponseSchema(oasUrl, strResponse, '/miscellaneas', ValidatorTestUtils.POST, 201)
    * if (report.hasErrors()) karate.fail(report.getMessages() + ' - '+ strResponse)

    Scenario: ESCENARIO Crear una nueva miscelanea con identificador de sistema fuente no válido DADO que el cliente ingreso los datos obligatorios y la llave única del cliente es válida y la llave del sistema fuente es inválido CUANDO se invoca la operación de la API ENTONCES el sistema no crea la miscelanea del cliente y retorna mensaje de excepción sistema fuente inválido
    Given path '/miscellaneas'
    And request read("crearMiscenaleaConSistemaFuenteInvalido.json")
    When method post
    Then status 400
    * string strResponse = response
    * def report = ValidatorTestUtils.validateResponseSchema(oasUrl, strResponse, '/miscellaneas', ValidatorTestUtils.POST, 400)
    * if (report.hasErrors()) karate.fail(report.getMessages() + ' - '+ strResponse)

    Scenario: ESCENARIO Crear una nueva miscelanea con identificador de sistema fuente no válido DADO que el cliente ingreso los datos obligatorios y la llave única del cliente es válida y la llave del sistema fuente es inválido CUANDO se invoca la operación de la API ENTONCES el sistema no crea la miscelanea del cliente y retorna mensaje de excepción sistema fuente inválido
    Given path '/miscellaneas'
    And request read("crearMiscenaleaClienteNoExistente.json")
    When method post
    Then status 404
    * string strResponse = response
    * def report = ValidatorTestUtils.validateResponseSchema(oasUrl, strResponse, '/miscellaneas', ValidatorTestUtils.POST, 404)
    * if (report.hasErrors()) karate.fail(report.getMessages() + ' - '+ strResponse)
