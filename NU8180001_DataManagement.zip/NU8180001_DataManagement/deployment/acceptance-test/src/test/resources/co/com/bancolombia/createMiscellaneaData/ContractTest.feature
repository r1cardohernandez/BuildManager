@contractTest
Feature: Escenarios de pruebas de contrato para la operacion: createMiscellaneaData
  Background:
    * url urlBase
    * def oasUrl = oasUrl
    * configure headers = headers
    * def requestExample = read('requestExample.json')
    * def ValidatorTestUtils = Java.type('co.com.bancolombia.utils.ValidatorTestUtils')

    Scenario: DADO que se desea realizar una prueba exitosa CUANDO se envia un request valido ENTONCES se espera un status 200 por valores validos
    Given path '/miscellaneas'
    And request requestExample
    When method POST
    Then status 201
    * string strResponse = response
    * def report = ValidatorTestUtils.validateResponseSchema(oasUrl, strResponse, '/miscellaneas', ValidatorTestUtils.POST, 201)
    * if (report.hasErrors()) karate.fail(report.getMessages() + ' - '+ strResponse)

    Scenario Outline: DADO que se desea validar el esquema del request CUANDO no se envia el campo <FIELD_NAME> ENTONCES se espera un status 400 por mensaje malformado
    Given path '/miscellaneas'
    And remove requestExample.<FIELD_NAME>
    And request requestExample
    When method POST
    Then status 400
    * string strResponse = response
    * def report = ValidatorTestUtils.validateResponseSchema(oasUrl, strResponse, '/miscellaneas', ValidatorTestUtils.POST, 400)
    * if (report.hasErrors()) karate.fail(report.getMessages() + ' - '+ strResponse)
    Examples:
    |	FIELD_NAME		|
    |data|
    | data.miscellanea |
    | data.miscellanea.sourceSystemID |
    | data.miscellanea.sourceSystemCustomerKey |
    | data.miscellanea.miscellaneaCategory |
    | data.miscellanea.value |
    | data.miscellanea.consecutive |

    Scenario Outline: DADO que se desea validar las restricciones de tamaño del campo <FIELD_NAME> CUANDO se envia el valor <FIELD_VALUE> ENTONCES se espera un status 400 por mensaje malformado
    Given path '/miscellaneas'
    And set requestExample.<FIELD_NAME> = <FIELD_VALUE>
    And request requestExample
    When method POST
    Then status 400
    * string strResponse = response
    * def report = ValidatorTestUtils.validateResponseSchema(oasUrl, strResponse, '/miscellaneas', ValidatorTestUtils.POST, 400)
    * if (report.hasErrors()) karate.fail(report.getMessages() + ' - '+ strResponse)
    Examples:
    | FIELD_NAME               | FIELD_VALUE |
    | data.miscellanea.sourceSystemCustomerKey | 's9kd28yfp3ay7kdi2w2a8tszx8x357t9o5q9ji8xk214efmoa66jqstuky0p2nkci2bo1akzzrg02sjqacq8ln9zfkhdannt1wtpzpv3fjchfg3vq9pyaxeoimtn904tq0p0h436651wknmtchtgh3zemg0qvi7esuqueiylwlfsj58jv8vrupcemzdyoompr8qrotiy8nlq75qlsaaql7i6fqpcvw2qcki6xe93ucfpvoij5cbaa4fss5fwts4a' |
    | data.miscellanea.sourceSystemCustomerKey | '' |

    Scenario Outline: DADO que se desea validar las restricciones de tamaño del campo <FIELD_NAME> CUANDO se envia el valor <FIELD_VALUE> ENTONCES se espera un status 400 por mensaje malformado
    Given path '/miscellaneas'
    And set requestExample.<FIELD_NAME> = <FIELD_VALUE>
    And request requestExample
    When method POST
    Then status 400
    * string strResponse = response
    * def report = ValidatorTestUtils.validateResponseSchema(oasUrl, strResponse, '/miscellaneas', ValidatorTestUtils.POST, 400)
    * if (report.hasErrors()) karate.fail(report.getMessages() + ' - '+ strResponse)
    Examples:
    | FIELD_NAME               | FIELD_VALUE |
    | data.miscellanea.miscellaneaCategory | 'mj2n07e92ikudb214afxfrpkbso1zfp89wkrvfot2jqvy22ngly4tc31u01xlkv80el2djk0y6846vot6mikus5b0a10wiundoqo0g5jvxn6pt9xla4p4337sfry8e68e9ylxdolnpy4md15gnvctggpn40dc7zw6b1qrn9cov9eyv365ik4qvqpzb3zt2pzdp8afphaxpl4d6p0bza9qtkba1xvm6zdv3y5twa8iw5v22amzf93i2xaevsxk9vp' |
    | data.miscellanea.miscellaneaCategory | '' |

    Scenario Outline: DADO que se desea validar las restricciones de tamaño del campo <FIELD_NAME> CUANDO se envia el valor <FIELD_VALUE> ENTONCES se espera un status 400 por mensaje malformado
    Given path '/miscellaneas'
    And set requestExample.<FIELD_NAME> = <FIELD_VALUE>
    And request requestExample
    When method POST
    Then status 400
    * string strResponse = response
    * def report = ValidatorTestUtils.validateResponseSchema(oasUrl, strResponse, '/miscellaneas', ValidatorTestUtils.POST, 400)
    * if (report.hasErrors()) karate.fail(report.getMessages() + ' - '+ strResponse)
    Examples:
    | FIELD_NAME               | FIELD_VALUE |
    | data.miscellanea.value | 'ulbfkd02kp4fqbfdegty8sah6mg4zkchvvejeylkgt093xuql6ch4ma2bpco86te8a99z3bf885bp0cdts1vrji47t7ov4tr4fk5dkxzwenfo4woi20h0it91yuey0lbfedndu1bdnjnvixp4ja3qeblhzkgf4dqmb6qyziviutpz49oc0nx6i0v4h2782y1opzk7p8kbgkyswbo19a7szgrtc3broazxx9rbi71hk5mupzd3tgl0qzys344kp2k' |
    | data.miscellanea.value | '' |

    Scenario Outline: DADO que se desea validar las restricciones de tamaño del campo <FIELD_NAME> CUANDO se envia el valor <FIELD_VALUE> ENTONCES se espera un status 400 por mensaje malformado
    Given path '/miscellaneas'
    And set requestExample.<FIELD_NAME> = <FIELD_VALUE>
    And request requestExample
    When method POST
    Then status 400
    * string strResponse = response
    * def report = ValidatorTestUtils.validateResponseSchema(oasUrl, strResponse, '/miscellaneas', ValidatorTestUtils.POST, 400)
    * if (report.hasErrors()) karate.fail(report.getMessages() + ' - '+ strResponse)
    Examples:
    | FIELD_NAME               | FIELD_VALUE |
    | data.miscellanea.consecutive | 'fy2h' |
    | data.miscellanea.consecutive | '' |
