@contractTest
Feature: Escenarios de pruebas de contrato para la operacion: updateMiscellaneaData
  Background:
    * url urlBase
    * def oasUrl = oasUrl
    * configure headers = headers
    * def requestExample = read('requestExample.json')
    * def ValidatorTestUtils = Java.type('co.com.bancolombia.utils.ValidatorTestUtils')

    Scenario: DADO que se desea realizar una prueba exitosa CUANDO se envia un request valido ENTONCES se espera un status 200 por valores validos
    Given path '/miscellaneas'
    And request requestExample
    When method PUT
    Then status 201
    * string strResponse = response
    * def report = ValidatorTestUtils.validateResponseSchema(oasUrl, strResponse, '/miscellaneas', ValidatorTestUtils.PUT, 201)
    * if (report.hasErrors()) karate.fail(report.getMessages() + ' - '+ strResponse)

    Scenario Outline: DADO que se desea validar el esquema del request CUANDO no se envia el campo <FIELD_NAME> ENTONCES se espera un status 400 por mensaje malformado
    Given path '/miscellaneas'
    And remove requestExample.<FIELD_NAME>
    And request requestExample
    When method PUT
    Then status 400
    * string strResponse = response
    * def report = ValidatorTestUtils.validateResponseSchema(oasUrl, strResponse, '/miscellaneas', ValidatorTestUtils.PUT, 400)
    * if (report.hasErrors()) karate.fail(report.getMessages() + ' - '+ strResponse)
    Examples:
    |	FIELD_NAME		|
    |data|
    | data.miscellanea |
    | data.miscellanea.sourceSystemID |
    | data.miscellanea.sourceSystemCustomerKey |
    | data.miscellanea.miscellaneaCategory |
    | data.miscellanea.value |
    | data.miscellanea.consecutive |

    Scenario Outline: DADO que se desea validar las restricciones de tamaño del campo <FIELD_NAME> CUANDO se envia el valor <FIELD_VALUE> ENTONCES se espera un status 400 por mensaje malformado
    Given path '/miscellaneas'
    And set requestExample.<FIELD_NAME> = <FIELD_VALUE>
    And request requestExample
    When method PUT
    Then status 400
    * string strResponse = response
    * def report = ValidatorTestUtils.validateResponseSchema(oasUrl, strResponse, '/miscellaneas', ValidatorTestUtils.PUT, 400)
    * if (report.hasErrors()) karate.fail(report.getMessages() + ' - '+ strResponse)
    Examples:
    | FIELD_NAME               | FIELD_VALUE |
    | data.miscellanea.sourceSystemCustomerKey | '16vvyoaap8hny2rd3sno8v52rsv0ouyrgtqwd5ubaxuntyfjj4tkcjlo0cop2jlajlzi320i15ixk0yc6b3d829hxjsuarhyr0fursebtx2qmcz8opu9igvm1elfobw33oir7zy1mrx5ht6no4u81xdwhgk54bol8tveha33hpkj354p226kosmmo1tgp388tdbqr3lyhiv31qfveyvqwqy7u5fzpa01muuovg0zezmabtdnyhosebtlk9z2ny8m' |
    | data.miscellanea.sourceSystemCustomerKey | '' |

    Scenario Outline: DADO que se desea validar las restricciones de tamaño del campo <FIELD_NAME> CUANDO se envia el valor <FIELD_VALUE> ENTONCES se espera un status 400 por mensaje malformado
    Given path '/miscellaneas'
    And set requestExample.<FIELD_NAME> = <FIELD_VALUE>
    And request requestExample
    When method PUT
    Then status 400
    * string strResponse = response
    * def report = ValidatorTestUtils.validateResponseSchema(oasUrl, strResponse, '/miscellaneas', ValidatorTestUtils.PUT, 400)
    * if (report.hasErrors()) karate.fail(report.getMessages() + ' - '+ strResponse)
    Examples:
    | FIELD_NAME               | FIELD_VALUE |
    | data.miscellanea.miscellaneaCategory | 'a1vhkofvx3hvmq4ocy1jy6qjcre7axd496ecsh9tsvjmg8d33tttsj5rk0izgd8cecko63q3m2ali7zdj5mm2np5dm4xvhy1pp80im3n3hc2ngh59ks4laj3fqnoswu9hospcpf7mea4wfozcbvecfr3palo53c1zx39tpbwcfckgfnebjitrvomggpu0hu5jo90vimuhv3135fg5vfom57sgvrmok59xd20lbdtpuds18gn3j5j6ev1cnrmaxvl' |
    | data.miscellanea.miscellaneaCategory | '' |

    Scenario Outline: DADO que se desea validar las restricciones de tamaño del campo <FIELD_NAME> CUANDO se envia el valor <FIELD_VALUE> ENTONCES se espera un status 400 por mensaje malformado
    Given path '/miscellaneas'
    And set requestExample.<FIELD_NAME> = <FIELD_VALUE>
    And request requestExample
    When method PUT
    Then status 400
    * string strResponse = response
    * def report = ValidatorTestUtils.validateResponseSchema(oasUrl, strResponse, '/miscellaneas', ValidatorTestUtils.PUT, 400)
    * if (report.hasErrors()) karate.fail(report.getMessages() + ' - '+ strResponse)
    Examples:
    | FIELD_NAME               | FIELD_VALUE |
    | data.miscellanea.value | 'c9h6kh9gnk5z7u9353ahm1r1bef2kiie668m66t22yxllnn3aiw4h2vxcrxzf3lpf84kg1wh5u0qpfie0k8uknn2vryedu89zfpgoxro0fharwd4jljtefqrrzfdkcpbn78qqaidzv0q48lirdyc0uq5m3dhcysn57wicctwigd4vbdc87wqh84763ymopbk548s0wr29fo1pffl6s0hxajm0egpcpc6lay5ikkb3ct21uce1ow8hf0141i8psn6' |
    | data.miscellanea.value | '' |

    Scenario Outline: DADO que se desea validar las restricciones de tamaño del campo <FIELD_NAME> CUANDO se envia el valor <FIELD_VALUE> ENTONCES se espera un status 400 por mensaje malformado
    Given path '/miscellaneas'
    And set requestExample.<FIELD_NAME> = <FIELD_VALUE>
    And request requestExample
    When method PUT
    Then status 400
    * string strResponse = response
    * def report = ValidatorTestUtils.validateResponseSchema(oasUrl, strResponse, '/miscellaneas', ValidatorTestUtils.PUT, 400)
    * if (report.hasErrors()) karate.fail(report.getMessages() + ' - '+ strResponse)
    Examples:
    | FIELD_NAME               | FIELD_VALUE |
    | data.miscellanea.consecutive | 'xyup' |
    | data.miscellanea.consecutive | '' |
