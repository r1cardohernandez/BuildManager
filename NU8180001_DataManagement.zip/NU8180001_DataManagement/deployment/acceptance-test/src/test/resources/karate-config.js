function fn() {
  const uuid = java.util.UUID.randomUUID();
  const config = {
    headers: {
      'message-id': uuid,
      'application-id': uuid,
      'id-consumer': 'NU7230001',
      'Authorization': 'Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6Imd3LWF3cy1la3MtbWRtLWp3dC1xYSJ9.eyJzdWIiOiJhcGktY29ubmVjdC1zY2FmZm9sZC1EYXRhTWFuYWdlbWVudC1kZXBsb3ltZW50IiwiaXNzIjoiaHR0cHM6Ly9hcGktYXdzLXFhLmFwcHMuYW1iaWVudGVzYmMuY29tL05VODE4MDAwMV9EYXRhTWFuYWdlbWVudCIsInRva2VuX3VzZSI6ImFjY2VzcyIsImNsaWVudF9pZCI6ImFwaS1jb25uZWN0LXNjYWZmb2xkLURhdGFNYW5hZ2VtZW50LWRlcGxveW1lbnQiLCJzY29wZSI6InNjYWZmb2xkLURhdGFNYW5hZ2VtZW50LWRlcGxveW1lbnQiLCJpYXQiOjE3NTUwNDAyMTgsImV4cCI6MTc1NTY0NTAxOH0.de0yZqBBaHTE2FmBpr4ZybZUye5Zok6_b8mMlZtKptvyv2d8ix50Paom1qTzVe99YtLg13UNuP7H_-vyl2LSEElzrlgFOddSOP_AgGKP9t7SJa7SU79y14Q9xKUriTDmH_CoZL38umFxiVHoNf-CMfw3IixY9w3_y9TRTsKCCBhdXp9wSDJysBDpUm2DHDyqrWDH2l6TpZvJHZVCJAQazKVZsDfoPGvYxtaurolVcKHaloMcV0YdPkJTubtUPq2QzXkEAsX1N-tDvvtc7P60Sr_0l_RLXbtvEKm9oEDzpHxD19h33CeziIx1Ihslv92o9guklmrwz8_6qFPcKIg1Jg'
    },
    oasUrl: 'co/com/bancolombia/CustomerMiscellaneaManagement-DataManagement_v1.0.yaml',
    urlBase: 'https://informacion-int-qa.apps.ambientesbc.com/mdm-integracion/v1/sales-service/customer-management/customer-miscellanea-management/data-management'
  };

  karate.configure('connectTimeout', 2000);
  karate.configure('readTimeout', 2000);
  karate.configure('ssl', true);
  return config;
}