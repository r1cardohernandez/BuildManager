package co.com.bancolombia.model.createmiscellaneas.exceptions;

import co.com.bancolombia.model.createmiscellaneas.exceptions.messages.BusinessErrorMessage;
import lombok.Getter;

@Getter
public class BusinessException extends RuntimeException{

    private final BusinessErrorMessage businessErrorMessage;

    public BusinessException(BusinessErrorMessage businessErrorMessage) {
        super(businessErrorMessage.getMessage());
        this.businessErrorMessage = businessErrorMessage;
    }


}