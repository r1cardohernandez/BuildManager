package co.com.bancolombia.model.createmiscellaneas.exceptions;

import co.com.bancolombia.model.createmiscellaneas.exceptions.messages.SystemErrorMessage;
import lombok.Getter;

@Getter
public class SystemException extends RuntimeException{
    private final SystemErrorMessage systemErrorMessage;

    public SystemException(SystemErrorMessage systemErrorMessage) {
        super(systemErrorMessage.getMessage());
        this.systemErrorMessage = systemErrorMessage;
    }

}
