package co.com.bancolombia.model.createmiscellaneas.exceptions.messages;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum BusinessErrorMessage {

    RECORD_NOT_FOUND("BP4046001","Cliente no existe",404, "Not Found" ),
    INVALID_REQUEST("BP400", "Identificación del sistema fuente no válido o no matriculado",400, "Bad Request" ),
    REQUEST_INVALID("BP400", "Bad Request",400, "Bad Request" ),
    CONSUMER_NOT_ALLOWED("BP403", "Permisos insuficientes",403, "Forbidden");

    private final String code;
    private final String message;
    private final Integer status;
    private final String title;

}
