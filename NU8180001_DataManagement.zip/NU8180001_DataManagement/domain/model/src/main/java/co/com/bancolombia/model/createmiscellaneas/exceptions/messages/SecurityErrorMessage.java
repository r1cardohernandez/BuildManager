package co.com.bancolombia.model.createmiscellaneas.exceptions.messages;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum SecurityErrorMessage {

    CONSUMER_NOT_ALLOWED("SA403", "Permisos insuficientes",403, "Forbidden"),
    ;
    private final String code;
    private final String message;
    private final Integer status;
    private final String title;
}
