package co.com.bancolombia.model.createmiscellaneas.exceptions.messages;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum SystemErrorMessage {

    INTERNAL_SERVER_ERROR("SP500","Ha ocurrido un error interno controlado en el servidor",500, "Internal Server Error"),
    ;

    private final String code;
    private final String message;
    private final Integer status;
    private final String title;

}
