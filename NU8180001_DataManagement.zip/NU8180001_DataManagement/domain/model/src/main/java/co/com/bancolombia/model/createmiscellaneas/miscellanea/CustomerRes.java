package co.com.bancolombia.model.createmiscellaneas.miscellanea;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@ToString
public class CustomerRes {

    private String sourceSystemCustomerKey;
    private String sourceSystemID;
}
