package co.com.bancolombia.model.createmiscellaneas.miscellanea;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@ToString
public class Miscellanea {

    private String sourceSystemID;

    private String sourceSystemCustomerKey;

    private String miscellaneaCategory;

    private String value;

    private String consecutive;

}
