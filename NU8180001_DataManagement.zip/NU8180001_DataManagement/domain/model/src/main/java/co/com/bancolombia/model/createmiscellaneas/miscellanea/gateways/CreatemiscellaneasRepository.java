package co.com.bancolombia.model.createmiscellaneas.miscellanea.gateways;

import reactor.core.publisher.Mono;
import java.util.Map;

public interface CreatemiscellaneasRepository {

    <T> Mono<T> crearMiscelanea(String url, Map<String,String> headers, Object bodyRequest, Class<T> responseType);

    }
