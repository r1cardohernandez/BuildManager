package co.com.bancolombia.model.createmiscellaneas.miscellanea.managementMiscellanea;

import co.com.bancolombia.model.createmiscellaneas.miscellanea.Miscellanea;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;
import lombok.ToString;

@lombok.Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@ToString
public class Data {
    private Miscellanea miscellanea;
}