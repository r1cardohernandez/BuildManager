package co.com.bancolombia.model.createmiscellaneas.miscellanea.managementMiscellanea;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
public class ManagementMisce {
    private Data data;
}
