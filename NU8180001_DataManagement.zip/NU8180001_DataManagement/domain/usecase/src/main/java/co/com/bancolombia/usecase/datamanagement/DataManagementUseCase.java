package co.com.bancolombia.usecase.datamanagement;

import co.com.bancolombia.model.createmiscellaneas.miscellanea.gateways.CreatemiscellaneasRepository;
import lombok.RequiredArgsConstructor;
import reactor.core.publisher.Mono;

import java.util.Map;

@RequiredArgsConstructor
public class DataManagementUseCase <T>{

    private final CreatemiscellaneasRepository createmiscellaneasRepository;

    public Mono<T> crearMiscelanea(String url, Map<String, String> headers, Object bodyRequest, Class<T> responseType){

        return createmiscellaneasRepository.crearMiscelanea(url, headers, bodyRequest, responseType);
    }
}
