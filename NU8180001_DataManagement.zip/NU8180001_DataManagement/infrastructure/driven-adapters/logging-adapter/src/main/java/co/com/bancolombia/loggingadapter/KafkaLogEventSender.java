package co.com.bancolombia.loggingadapter;

import co.com.bancolombia.kafka.loggin.infraestructure.kafkaproducer.LogginAdapter;
import co.com.bancolombia.loggingadapter.model.ErrorLogEvent;
import co.com.bancolombia.loggingadapter.model.HttpErrorLogEvent;
import co.com.bancolombia.loggingadapter.model.HttpLogEvent;
import co.com.bancolombia.loggingadapter.model.LogEvent;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.time.Instant;

@Component
public class KafkaLogEventSender {
    private final LogginAdapter kafkaProducer;

    public KafkaLogEventSender(LogginAdapter kafkaProducer) {
        this.kafkaProducer = kafkaProducer;

    }

    public Mono<Void> loggingHttpAdapter(HttpLogEvent event) {
        return kafkaProducer.loggingAdapterEvent(
                event.getEventType(),
                event.getBody(),
                event.getHeaders(),
                event.getHttpMethod(),
                event.getMessageId(),
                event.getConsumerId(),
                event.getPath(),
                Instant.now(),
                "",
                event.getStatus());
    }


    public Mono<Void> loggingAdapter(LogEvent event) {
        return kafkaProducer.loggingAdapterEvent(
                event.getEventType(),
                event.getBody(),
                null,
                null,
                event.getMessageId(),
                event.getConsumerId(),
                event.getPath(),
                Instant.now(),
                "",
                null);
    }


    public Mono<Void> loggingHttpErrorAdapter(HttpErrorLogEvent event) {
        return kafkaProducer.loggingAdapterErrorEvent(
                event.getBody(),
                event.getHeaders(),
                event.getHttpMethod(),
                event.getMessageId(),
                event.getConsumerId(),
                event.getPath(),
                Instant.now(),
                "",
                event.getStatus(),
                event.getError());
    }

    public Mono<Void> loggingErrorAdapter(ErrorLogEvent event) {
        return kafkaProducer.loggingAdapterErrorEvent(
                event.getBody(),
                event.getHeaders(),
                null,
                event.getMessageId(),
                event.getConsumerId(),
                null,
                Instant.now(),
                "",
                null,
                event.getError());
    }
}