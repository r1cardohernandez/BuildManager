package co.com.bancolombia.loggingadapter;


import co.com.bancolombia.domain.models.enums.EventType;
import co.com.bancolombia.loggingadapter.model.HttpErrorLogEvent;
import co.com.bancolombia.loggingadapter.model.HttpLogEvent;
import co.com.bancolombia.loggingadapter.model.LogEvent;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.server.ServerRequest;
import reactor.core.publisher.Mono;

import java.util.Map;

@Service
@RequiredArgsConstructor
@Slf4j
public class KafkaLogEventService {

    private static final String SERVICE_ERROR = "Error executing loggingHttpErrorAdapter for ERROR";
    private final KafkaLogEventSender loggingAdapter;


    public Mono<Void> logMQRequest(ServerRequest request, String messageRq) {
        return logMQ(EventType.REQUEST,request,messageRq);
    }

    public Mono<Void> logMQResponse(ServerRequest request, String messageRs) {
        return logMQ(EventType.RESPONSE,request,messageRs);
    }
    public Mono<Void> logHttpRequest(ServerRequest serverRequest, Object requestBody) {
        return logHttp(serverRequest,requestBody,EventType.REQUEST,null);
    }

    public Mono<Void> logHttpResponse(ServerRequest serverRequest, Object responseBody, Integer statusCode) {
        return logHttp(serverRequest,responseBody,EventType.RESPONSE,statusCode);
    }

    public Mono<Void> logHttpError(ServerRequest serverRequest, Object body, int status, Exception error) {
        String messageId = serverRequest.headers().firstHeader("message-id");
        String consumerId = serverRequest.headers().firstHeader("id-consumer");
        String path = serverRequest.path();
        String method = serverRequest.method().name();
        Map<String, String> headers = serverRequest.headers().asHttpHeaders().toSingleValueMap();

        return loggingAdapter.loggingHttpErrorAdapter(
                HttpErrorLogEvent.builder()
                        .messageId(messageId)
                        .consumerId(consumerId)
                        .path(path)
                        .body(body)
                        .headers(headers)
                        .httpMethod(method)
                        .status(status)
                        .error(error)
                        .build());
    }

    private Mono<Void> logMQ(EventType eventType, ServerRequest serverRequest, String message) {
        String messageId = serverRequest.headers().firstHeader("message-id");
        String consumerId = serverRequest.headers().firstHeader("id-consumer");
        String path = serverRequest.path();

        return loggingAdapter.loggingAdapter(
                LogEvent.builder()
                        .eventType(eventType)
                        .messageId(messageId)
                        .consumerId(consumerId)
                        .path(path)
                        .body(message).build());
    }

    private Mono<Void> logHttp(ServerRequest serverRequest, Object requestBody,
                               EventType eventType, Integer statusCode) {
        String messageId = serverRequest.headers().firstHeader("message-id");
        String consumerId = serverRequest.headers().firstHeader("id-consumer");
        String path = serverRequest.path();
        String method = serverRequest.method().name();
        Map<String, String> headers = serverRequest.headers().asHttpHeaders().toSingleValueMap();

        return loggingAdapter.loggingHttpAdapter(
                HttpLogEvent.builder()
                        .eventType(eventType)
                        .messageId(messageId)
                        .consumerId(consumerId)
                        .path(path)
                        .body(requestBody)
                        .headers(headers)
                        .httpMethod(method)
                        .status(statusCode)
                        .build());
    }

}
