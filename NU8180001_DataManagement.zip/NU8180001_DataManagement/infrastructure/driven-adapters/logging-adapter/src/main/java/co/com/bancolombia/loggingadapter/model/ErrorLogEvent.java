package co.com.bancolombia.loggingadapter.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

@Data
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
public class ErrorLogEvent {
    private String messageId;
    private String consumerId;
    private Object body;
    private Map<String, String> headers;
    private Exception error;
}
