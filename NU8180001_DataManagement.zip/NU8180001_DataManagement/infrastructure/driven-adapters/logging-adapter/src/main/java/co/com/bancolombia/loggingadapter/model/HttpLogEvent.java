package co.com.bancolombia.loggingadapter.model;

import co.com.bancolombia.domain.models.enums.EventType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

@Data
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
public class HttpLogEvent {
    private EventType eventType;
    private String messageId;
    private String consumerId;
    private String path;
    private Object body;
    private Map<String, String> headers;
    private String httpMethod;
    private Integer status;
}