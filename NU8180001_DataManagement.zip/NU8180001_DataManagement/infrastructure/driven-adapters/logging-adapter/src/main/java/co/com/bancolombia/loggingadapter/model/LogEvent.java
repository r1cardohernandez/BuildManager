package co.com.bancolombia.loggingadapter.model;

import co.com.bancolombia.domain.models.enums.EventType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
public class LogEvent {
    private EventType eventType;
    private String messageId;
    private String consumerId;
    private String path;
    private Object body;
}
