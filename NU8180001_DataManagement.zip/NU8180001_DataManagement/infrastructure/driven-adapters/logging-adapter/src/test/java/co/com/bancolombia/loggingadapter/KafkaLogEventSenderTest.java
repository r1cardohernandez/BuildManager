package co.com.bancolombia.loggingadapter;

import co.com.bancolombia.domain.models.enums.EventType;
import co.com.bancolombia.kafka.loggin.infraestructure.kafkaproducer.LogginAdapter;
import co.com.bancolombia.loggingadapter.model.ErrorLogEvent;
import co.com.bancolombia.loggingadapter.model.HttpErrorLogEvent;
import co.com.bancolombia.loggingadapter.model.HttpLogEvent;
import co.com.bancolombia.loggingadapter.model.LogEvent;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

class KafkaLogEventSenderTest {

    @Mock
    private LogginAdapter kafkaProducer;

    KafkaLogEventSender kafkaLogEventSender;


    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        kafkaLogEventSender = new KafkaLogEventSender(kafkaProducer);

    }

    @Test
    void loggingAdapterEventTest(){
        Integer body = 12;

        when(kafkaProducer.loggingAdapterEvent(any(),any(),any(),any(),any(),any(),any(),any(),any(),any())).thenReturn(Mono.empty());
        kafkaLogEventSender.loggingAdapter(
                        LogEvent.builder()
                                .eventType(EventType.REQUEST)
                                .messageId("messageId")
                                .consumerId("consummer-id")
                                .path("path")
                                .body(body).build())
                .as(StepVerifier::create)
                .verifyComplete();
    }

    @Test
    void loggingAdapterErrorEventTest(){
        Integer body = 12;

        when(kafkaProducer.loggingAdapterErrorEvent(any(),any(),any(),any(),any(),any(),any(),any(),any(),any())).thenReturn(Mono.empty());

        kafkaLogEventSender.loggingErrorAdapter(
                        ErrorLogEvent.builder()
                                .messageId("messageId")
                                .consumerId("consumerId")
                                .body(body)
                                .headers(null)
                                .error(null)
                                .build())
                .as(StepVerifier::create)
                .verifyComplete();
    }


    @Test
    void loggingAdapterHTTPEventTest(){
        Integer body = 12;

        when(kafkaProducer.loggingAdapterEvent(any(),any(),any(),any(),any(),any(),any(),any(),any(),any())).thenReturn(Mono.empty());
        kafkaLogEventSender.loggingHttpAdapter(
                        HttpLogEvent.builder()
                                .eventType(EventType.RESPONSE)
                                .messageId("messageId")
                                .consumerId("consumerId")
                                .path("path")
                                .body(body)
                                .headers(null)
                                .httpMethod("POST")
                                .status(200)
                                .build())
                .as(StepVerifier::create)
                .verifyComplete();
    }

    @Test
    void loggingAdapterHTTPErrorEventTest(){
        Integer body = 12;

        when(kafkaProducer.loggingAdapterErrorEvent(any(),any(),any(),any(),any(),any(),any(),any(),any(),any())).thenReturn(Mono.empty());
        kafkaLogEventSender.loggingHttpErrorAdapter(
                        HttpErrorLogEvent.builder()
                                .messageId("messageId")
                                .consumerId("consumerId")
                                .path("path")
                                .body(body)
                                .headers(null)
                                .httpMethod("POST")
                                .status(404)
                                .error(null)
                                .build())
                .as(StepVerifier::create)
                .verifyComplete();
    }
}
