package co.com.bancolombia.loggingadapter;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpMethod;
import org.springframework.mock.web.reactive.function.server.MockServerRequest;
import org.springframework.web.reactive.function.server.ServerRequest;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.net.URI;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

class KafkaLogEventServiceTest {

    @Mock
    KafkaLogEventSender kafkaLogEventSender;

    KafkaLogEventService kafkaLogEventService;


    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        kafkaLogEventService = new KafkaLogEventService(kafkaLogEventSender);

    }

    @Test
    void loggingAdapterServiceMQRequestTest(){
        ServerRequest request = obtainRequest();
        when(kafkaLogEventSender.loggingAdapter(any())).thenReturn(Mono.empty());

        kafkaLogEventService.logMQRequest(request, "messageRq")
                .as(StepVerifier::create)
                .verifyComplete();
    }

    @Test
    void loggingAdapterServiceMQResponseTest(){
        ServerRequest request = obtainRequest();
        when(kafkaLogEventSender.loggingAdapter(any())).thenReturn(Mono.empty());

        kafkaLogEventService.logMQResponse(request, "messageRq")
                .as(StepVerifier::create)
                .verifyComplete();
    }

    @Test
    void loggingAdapterServiceHttpRequestTest(){
        ServerRequest request = obtainRequest();
        when(kafkaLogEventSender.loggingHttpAdapter(any())).thenReturn(Mono.empty());

        kafkaLogEventService.logHttpRequest(request, "body")
                .as(StepVerifier::create)
                .verifyComplete();
    }

    @Test
    void loggingAdapterServiceHttpResponseTest(){
        ServerRequest request = obtainRequest();
        when(kafkaLogEventSender.loggingHttpAdapter(any())).thenReturn(Mono.empty());

        kafkaLogEventService.logHttpResponse(request, "body", 200)
                .as(StepVerifier::create)
                .verifyComplete();
    }

    @Test
    void loggingAdapterServiceErrorTest(){
        ServerRequest request = obtainRequest();
        when(kafkaLogEventSender.loggingHttpErrorAdapter(any())).thenReturn(Mono.empty());

        kafkaLogEventService.logHttpError(request, "body", 200, null)
                .as(StepVerifier::create)
                .verifyComplete();
    }

    private ServerRequest obtainRequest(){
        return MockServerRequest.builder()
                .method(HttpMethod.POST)
                .uri(URI.create("http://localhost/test"))
                .header("message-id", "cf5e04d7-519b-4834-ab75-3b02f7389f20")
                .header("consumer-id", "NU4680001")
                .build();
    }

}
