package co.com.bancolombia.policymanager;

import co.com.bancolombia.policymanager.config.PolicyManagerConfig;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.net.URI;

@Configuration
public class PolicyManagerConf {

    private static final int CACHE_EXPIRE_AFTER_SECONDS = 3600;
    private final String policyUri;

    public PolicyManagerConf(@Value("${service.internal.policy-manager.uri}") String policyUri) {
        this.policyUri = policyUri;
    }

    @Bean
    public PolicyManagerConnectorAsync policyManagerConfig() {
        return new PolicyManagerConnectorAsync(
                PolicyManagerConfig.builder()
                        .uri(URI.create(policyUri))
                        .cacheExpireAfter(CACHE_EXPIRE_AFTER_SECONDS)
                        .build()
        );
    }
}
