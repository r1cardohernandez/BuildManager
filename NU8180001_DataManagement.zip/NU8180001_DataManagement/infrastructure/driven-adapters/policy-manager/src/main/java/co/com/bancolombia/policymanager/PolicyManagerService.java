package co.com.bancolombia.policymanager;

import co.com.bancolombia.policymanager.exceptions.InvalidConsumerException;
import co.com.bancolombia.policymanager.exceptions.PolicyManagerException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

@Component
@RequiredArgsConstructor
public class PolicyManagerService {

    private final PolicyManagerConnectorAsync policyManagerConnectorAsync;

    public Mono<Boolean> verifyConsumer(String namespace, String applicationId, String operationId, String messageId) {
        return policyManagerConnectorAsync.verifyConsumer(namespace, applicationId, operationId, messageId)
                .map(response -> Boolean.TRUE)
                .onErrorResume(InvalidConsumerException.class, error -> Mono.just(Boolean.FALSE))
                .onErrorResume(PolicyManagerException.class, error -> Mono.just(Boolean.FALSE));
    }
}

