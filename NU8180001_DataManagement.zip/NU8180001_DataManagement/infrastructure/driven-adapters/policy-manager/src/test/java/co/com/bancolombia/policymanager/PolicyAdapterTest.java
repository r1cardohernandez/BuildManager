package co.com.bancolombia.policymanager;

import co.com.bancolombia.policymanager.dtos.ServiceCatalogResponse;
import co.com.bancolombia.policymanager.exceptions.InvalidConsumerException;
import co.com.bancolombia.policymanager.exceptions.PolicyManagerException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

class PolicyAdapterTest {

    @Mock
    private PolicyManagerConnectorAsync policyManagerConnectorAsync;

    PolicyManagerService policyManagerService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        policyManagerService = new PolicyManagerService(policyManagerConnectorAsync);

    }


    @Test
    void policyAdapterTest() {
        ServiceCatalogResponse sc = new ServiceCatalogResponse();

        when(policyManagerConnectorAsync.verifyConsumer(any(), any(), any(), any()))
                .thenReturn(Mono.just(sc));

        policyManagerService.verifyConsumer("namespace", "applicationId", "operation", "message-id")
                .as(StepVerifier::create)
                .assertNext(Assertions::assertTrue)
                .verifyComplete();
    }

    @Test
    void policyAdapterErrorTest() {
        when(policyManagerConnectorAsync.verifyConsumer(any(), any(), any(), any()))
                .thenReturn(Mono.error(new InvalidConsumerException("Error")));

        policyManagerService.verifyConsumer("namespace", "applicationId", "operation", "message-id")
                .as(StepVerifier::create)
                .assertNext(Assertions::assertFalse)
                .verifyComplete();
    }

    @Test
    void policyAdapterError2Test() {
        when(policyManagerConnectorAsync.verifyConsumer(any(), any(), any(), any()))
                .thenReturn(Mono.error(new PolicyManagerException("Error")));

        policyManagerService.verifyConsumer("namespace", "applicationId", "operation", "message-id")
                .as(StepVerifier::create)
                .assertNext(Assertions::assertFalse)
                .verifyComplete();
    }



}
