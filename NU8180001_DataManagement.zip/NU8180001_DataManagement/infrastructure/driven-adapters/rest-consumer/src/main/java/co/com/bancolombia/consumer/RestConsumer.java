package co.com.bancolombia.consumer;

import co.com.bancolombia.consumer.response.Miscellanea_Res;
import co.com.bancolombia.model.createmiscellaneas.exceptions.BusinessException;
import co.com.bancolombia.model.createmiscellaneas.exceptions.SystemException;
import co.com.bancolombia.model.createmiscellaneas.exceptions.messages.BusinessErrorMessage;
import co.com.bancolombia.model.createmiscellaneas.exceptions.messages.SystemErrorMessage;
import co.com.bancolombia.model.createmiscellaneas.miscellanea.gateways.CreatemiscellaneasRepository;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import lombok.RequiredArgsConstructor;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import reactor.core.publisher.Mono;

import java.util.Map;

@Service
@RequiredArgsConstructor
public class RestConsumer implements CreatemiscellaneasRepository {

    private final WebClient client;

    @Override
    @CircuitBreaker(name = "crearMiscelanea")
    public <T> Mono<T> crearMiscelanea(String url, Map<String, String> headers, Object bodyRequest, Class<T> responseType) {

        System.out.println("url = " + url);
        System.out.println("headers = " + headers);
        System.out.println("bodyRequest = " + bodyRequest.toString());

        WebClient.RequestBodySpec request = client
                .put()
                .uri(url);

        // Agregar headers dinámicos
        if (headers != null) {
            headers.forEach(request::header);
        }

        String operation = (headers != null) ? headers.get("Operation") : null;

        return request
                .body(Mono.just(bodyRequest), Object.class)
                .exchangeToMono(response -> response.toEntity(responseType))
                .flatMap(responseEntity -> handleResponse(responseEntity, responseType));
    }

    private <T> Mono<T> handleResponse(ResponseEntity<T> responseEntity, Class<T> responseType) {
        int statusCode = responseEntity.getStatusCode().value();
        T body = responseEntity.getBody();

        if (statusCode == HttpStatus.CREATED.value()) {
            return Mono.just(body);
        }

        if ((statusCode == HttpStatus.BAD_REQUEST.value() || statusCode == HttpStatus.NOT_FOUND.value())
                && responseType.equals(Miscellanea_Res.class)
                && body instanceof Miscellanea_Res) {
            return handleBusinessErrorFromBody((Miscellanea_Res) body);
        }

        return Mono.error(mapErrorByStatusCode(statusCode));
    }

    @SuppressWarnings("unchecked")
    private <T> Mono<T> handleBusinessErrorFromBody(Miscellanea_Res res) {
        if (res.getCodigoSalida() == null) {
            return Mono.error(new BusinessException(BusinessErrorMessage.REQUEST_INVALID));
        }

        return switch (res.getCodigoSalida()) {
            case "1" -> Mono.error(new BusinessException(BusinessErrorMessage.INVALID_REQUEST));
            case "3" -> Mono.error(new BusinessException(BusinessErrorMessage.INVALID_REQUEST));
            case "4" -> Mono.error(new BusinessException(BusinessErrorMessage.INVALID_REQUEST));
            case "5" -> Mono.error(new BusinessException(BusinessErrorMessage.RECORD_NOT_FOUND));
            case "10" -> Mono.error(new BusinessException(BusinessErrorMessage.REQUEST_INVALID));
            default -> Mono.error(new BusinessException(BusinessErrorMessage.REQUEST_INVALID));
        };
    }

    private RuntimeException mapErrorByStatusCode(int statusCode) {
        return switch (statusCode) {
            case 401 -> new BusinessException(BusinessErrorMessage.CONSUMER_NOT_ALLOWED);
            case 404 -> new BusinessException(BusinessErrorMessage.RECORD_NOT_FOUND);
            case 422 -> new BusinessException(BusinessErrorMessage.INVALID_REQUEST);
            default -> new SystemException(SystemErrorMessage.INTERNAL_SERVER_ERROR);
        };
    }
}