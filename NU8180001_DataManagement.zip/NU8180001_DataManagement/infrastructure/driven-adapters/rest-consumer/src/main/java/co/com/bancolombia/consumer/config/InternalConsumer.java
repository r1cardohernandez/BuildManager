package co.com.bancolombia.consumer.config;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder(toBuilder = true)
public class InternalConsumer {
    @JsonProperty("cerpublic")
    private String cerpublic;
    @JsonProperty("cerprivate")
    private String cerprivate;

}
