package co.com.bancolombia.consumer.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString

public class Miscellanea_Req {

    @JsonProperty ("tipo_operacion")
    private String tipoOperacion;

    @JsonProperty ("pkey_src_object")
    private String pkeySrcObject;

    @JsonProperty ("rowid_system")
    private String rowidSystem;

    @JsonProperty ("categoria_miscelanea")
    private String categoriaMiscelanea;

    @JsonProperty ("valor_miscelanea")
    private String valorMiscelanea;

    @JsonProperty ("consecutivo_miscelanea")
    private String consecutivoMiscelanea;

}
