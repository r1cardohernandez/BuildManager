package co.com.bancolombia.consumer.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString

public class Miscellanea_Res {
    @JsonProperty("pkey_src_object")
    private String pkeySrcObject;

    @JsonProperty("rowid_system")
    private String rowidSystem;

    @JsonProperty("codigo_salida")
    private String codigoSalida;
}
