package co.com.bancolombia.consumer;

import co.com.bancolombia.consumer.response.Miscellanea_Res;
import co.com.bancolombia.model.createmiscellaneas.exceptions.BusinessException;
import co.com.bancolombia.model.createmiscellaneas.exceptions.SystemException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Map;
import java.util.function.Function;

import static junit.framework.TestCase.assertEquals;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;

@ExtendWith(MockitoExtension.class)
class RestConsumerTest {

    @Mock
    private WebClient webClient;

    @Mock
    private WebClient.RequestBodyUriSpec requestBodyUriSpec;

    @Mock
    private WebClient.RequestBodySpec requestBodySpec;

    @Mock
    private WebClient.RequestHeadersSpec requestHeadersSpec;

    @InjectMocks
    private RestConsumer restConsumer;

    @Test
    void shouldHandleNullHeadersGracefully() {
        // Arrange
        String url = "http://test-url.com";
        Map<String, String> headers = null; // Headers nulo
        Object bodyRequest = new Object();
        String expectedResponse = "Success Response";

        Mockito.when(webClient.put()).thenReturn(requestBodyUriSpec);
        Mockito.when(requestBodyUriSpec.uri(url)).thenReturn(requestBodySpec);
        Mockito.when(requestBodySpec.body(Mockito.any(Mono.class), Mockito.eq(Object.class))).thenReturn(requestHeadersSpec);
        Mockito.when(requestHeadersSpec.exchangeToMono(Mockito.any()))
                .thenAnswer(invocation -> {
                    Function<ClientResponse, Mono<ResponseEntity<String>>> responseFunction = invocation.getArgument(0);
                    ClientResponse mockResponse = ClientResponse.create(HttpStatus.CREATED).body("Success Response").build();
                    return responseFunction.apply(mockResponse);
                });

        // Act
        Mono<String> resultMono = restConsumer.crearMiscelanea(url, headers, bodyRequest, String.class);
        String result = resultMono.block();

        // Assert
        assertEquals(expectedResponse, result);
    }

    @ParameterizedTest
    @CsvSource({
            "key, Cliente no existe"
    })
    void shouldHandleRecordNotFoundBasedOnOperation(String operation, String expectedErrorMessage) {
        // Arrange
        String url = "http://test-url.com";
        Map<String, String> headers = Map.of("Operation", operation);
        Object bodyRequest = new Object();

        Mockito.when(webClient.put()).thenReturn(requestBodyUriSpec);
        Mockito.when(requestBodyUriSpec.uri(url)).thenReturn(requestBodySpec);
        Mockito.when(requestBodySpec.header(Mockito.anyString(), Mockito.anyString())).thenReturn(requestBodySpec);
        Mockito.when(requestBodySpec.body(Mockito.any(Mono.class), Mockito.eq(Object.class))).thenReturn(requestHeadersSpec);
        Mockito.when(requestHeadersSpec.exchangeToMono(Mockito.any()))
                .thenAnswer(invocation -> {
                    Function<ClientResponse, Mono<ResponseEntity<String>>> responseFunction = invocation.getArgument(0);
                    ClientResponse mockResponse = ClientResponse.create(HttpStatus.NOT_FOUND).build();
                    return responseFunction.apply(mockResponse);
                });

        // Act
        Mono<String> resultMono = restConsumer.crearMiscelanea(url, headers, bodyRequest, String.class);

        // Assert
        BusinessException exception = assertThrows(BusinessException.class, resultMono::block);
        assertEquals(expectedErrorMessage, exception.getMessage());
    }



    @ParameterizedTest
    @CsvSource({
            "200, Success Response",
            "404, null",
            "422, null",
            "401, null",
            "500, null"
    })
    void shouldHandleDifferentStatusCodes(int statusCode, String expectedResponse) {
        // Arrange
        String url = "http://test-url.com";
        Map<String, String> headers = Map.of("Operation", "key"); // Cambiar a otro valor para probar diferentes rutas en 404
        Object bodyRequest = new Object();

        Mockito.when(webClient.put()).thenReturn(requestBodyUriSpec);
        Mockito.when(requestBodyUriSpec.uri(url)).thenReturn(requestBodySpec);
        Mockito.when(requestBodySpec.header(Mockito.anyString(), Mockito.anyString())).thenReturn(requestBodySpec);
        Mockito.when(requestBodySpec.body(Mockito.any(Mono.class), Mockito.eq(Object.class))).thenReturn(requestHeadersSpec);
        Mockito.when(requestHeadersSpec.exchangeToMono(Mockito.any()))
                .thenAnswer(invocation -> {
                    Function<ClientResponse, Mono<ResponseEntity<String>>> responseFunction = invocation.getArgument(0);
                    ClientResponse mockResponse = ClientResponse.create(HttpStatus.valueOf(statusCode))
                            .body(expectedResponse)
                            .build();
                    return responseFunction.apply(mockResponse);
                });

        // Act
        Mono<String> resultMono = restConsumer.crearMiscelanea(url, headers, bodyRequest, String.class);

        // Assert
        if (statusCode == 201) {
            assertEquals(expectedResponse, resultMono.block());
        } else if (statusCode == 404) {
            BusinessException exception = assertThrows(BusinessException.class, resultMono::block);
            if (headers.get("Operation").equals("key")) {
                assertEquals("Cliente no existe", exception.getMessage());
            } else {
                assertEquals("Identificación del sistema fuente no válido o no matriculado", exception.getMessage());
            }
        } else if (statusCode == 422) {
            BusinessException exception = assertThrows(BusinessException.class, resultMono::block);
            assertEquals("Identificación del sistema fuente no válido o no matriculado", exception.getMessage());
        } else if (statusCode == 401) {
            BusinessException exception = assertThrows(BusinessException.class, resultMono::block);
            assertEquals("Permisos insuficientes", exception.getMessage());
        } else {
            SystemException exception = assertThrows(SystemException.class, resultMono::block);
            assertEquals("Ha ocurrido un error interno controlado en el servidor", exception.getMessage());
        }
    }


    @Test
    void shouldProcessHeadersWhenNotNull() {
        // Arrange
        String url = "http://test-url.com";
        Map<String, String> headers = Map.of("Operation", "testOperation", "Custom-Header", "HeaderValue");
        Object bodyRequest = new Object();
        String expectedResponse = "Success Response";

        Mockito.when(webClient.put()).thenReturn(requestBodyUriSpec);
        Mockito.when(requestBodyUriSpec.uri(url)).thenReturn(requestBodySpec);
        Mockito.when(requestBodySpec.header(Mockito.anyString(), Mockito.anyString())).thenReturn(requestBodySpec);
        Mockito.when(requestBodySpec.body(Mockito.any(Mono.class), Mockito.eq(Object.class))).thenReturn(requestHeadersSpec);
        Mockito.when(requestHeadersSpec.exchangeToMono(Mockito.any()))
                .thenAnswer(invocation -> {
                    Function<ClientResponse, Mono<ResponseEntity<String>>> responseFunction = invocation.getArgument(0);
                    ClientResponse mockResponse = ClientResponse.create(HttpStatus.CREATED).body("Success Response").build();
                    return responseFunction.apply(mockResponse);
                });

        // Act
        Mono<String> resultMono = restConsumer.crearMiscelanea(url, headers, bodyRequest, String.class);
        String result = resultMono.block();

        // Assert
        ArgumentCaptor<String> headerNameCaptor = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> headerValueCaptor = ArgumentCaptor.forClass(String.class);

        Mockito.verify(requestBodySpec, Mockito.atLeastOnce())
                .header(headerNameCaptor.capture(), headerValueCaptor.capture());

        // Validar que los headers pasados al método header son los correctos
        List<String> capturedNames = headerNameCaptor.getAllValues();
        List<String> capturedValues = headerValueCaptor.getAllValues();

        assertTrue(capturedNames.contains("Operation"));
        assertTrue(capturedValues.contains("testOperation"));
        assertTrue(capturedNames.contains("Custom-Header"));
        assertTrue(capturedValues.contains("HeaderValue"));

        // Validar el resultado final
        assertEquals(expectedResponse, result);
    }

    @Test
    void shouldThrowBusinessExceptionForCodigoSalida1() {
        // Arrange
        String url = "http://test-url.com";
        Map<String, String> headers = Map.of("Operation", "testOperation");
        Object bodyRequest = new Object();

        // Simular el cuerpo con codigo_salida "1"
        Miscellanea_Res responseBody = new Miscellanea_Res();
        responseBody.setCodigoSalida("1");

        Mockito.when(webClient.put()).thenReturn(requestBodyUriSpec);
        Mockito.when(requestBodyUriSpec.uri(url)).thenReturn(requestBodySpec);
        Mockito.when(requestBodySpec.header(Mockito.anyString(), Mockito.anyString())).thenReturn(requestBodySpec);
        Mockito.when(requestBodySpec.body(Mockito.any(Mono.class), Mockito.eq(Object.class))).thenReturn(requestHeadersSpec);
        Mockito.when(requestHeadersSpec.exchangeToMono(Mockito.any()))
                .thenAnswer(invocation -> {
                    Function<ClientResponse, Mono<ResponseEntity<Miscellanea_Res>>> responseFunction = invocation.getArgument(0);
                    ClientResponse mockResponse = ClientResponse
                            .create(HttpStatus.BAD_REQUEST)
                            .header("Content-Type", "application/json")
                            .body("{\"codigo_salida\":\"1\"}")
                            .build();

                    // Aquí devolvemos directamente un ResponseEntity simulado
                    return Mono.just(new ResponseEntity<>(responseBody, HttpStatus.BAD_REQUEST));
                });

        // Act & Assert
        BusinessException exception = assertThrows(
                BusinessException.class,
                () -> restConsumer.crearMiscelanea(url, headers, bodyRequest, Miscellanea_Res.class).block()
        );
        assertEquals("Identificación del sistema fuente no válido o no matriculado", exception.getMessage());
    }

    @Test
    void shouldThrowBusinessExceptionForCodigoSalida5() {
        // Arrange
        String url = "http://test-url.com";
        Map<String, String> headers = Map.of("Operation", "testOperation");
        Object bodyRequest = new Object();

        // Simular el cuerpo con codigo_salida "5"
        Miscellanea_Res responseBody = new Miscellanea_Res();
        responseBody.setCodigoSalida("5");

        Mockito.when(webClient.put()).thenReturn(requestBodyUriSpec);
        Mockito.when(requestBodyUriSpec.uri(url)).thenReturn(requestBodySpec);
        Mockito.when(requestBodySpec.header(Mockito.anyString(), Mockito.anyString())).thenReturn(requestBodySpec);
        Mockito.when(requestBodySpec.body(Mockito.any(Mono.class), Mockito.eq(Object.class))).thenReturn(requestHeadersSpec);
        Mockito.when(requestHeadersSpec.exchangeToMono(Mockito.any()))
                .thenAnswer(invocation -> {
                    return Mono.just(new ResponseEntity<>(responseBody, HttpStatus.BAD_REQUEST));
                });

        // Act & Assert
        BusinessException exception = assertThrows(
                BusinessException.class,
                () -> restConsumer.crearMiscelanea(url, headers, bodyRequest, Miscellanea_Res.class).block()
        );
        assertEquals("Cliente no existe", exception.getMessage());
    }


    @Test
    void shouldReturnResponseForHttp200() {
        // Arrange
        String url = "http://test-url.com";
        Map<String, String> headers = Map.of("Operation", "testOperation");
        Object bodyRequest = new Object();
        String expectedResponse = "Success Response";

        Mockito.when(webClient.put()).thenReturn(requestBodyUriSpec);
        Mockito.when(requestBodyUriSpec.uri(url)).thenReturn(requestBodySpec);
        Mockito.when(requestBodySpec.header(Mockito.anyString(), Mockito.anyString())).thenReturn(requestBodySpec);
        Mockito.when(requestBodySpec.body(Mockito.any(Mono.class), Mockito.eq(Object.class))).thenReturn(requestHeadersSpec);
        Mockito.when(requestHeadersSpec.exchangeToMono(Mockito.any()))
                .thenAnswer(invocation -> {
                    Function<ClientResponse, Mono<ResponseEntity<String>>> responseFunction = invocation.getArgument(0);
                    ClientResponse mockResponse = ClientResponse.create(HttpStatus.CREATED).body("Success Response").build();
                    return responseFunction.apply(mockResponse);
                });

        // Act
        Mono<String> resultMono = restConsumer.crearMiscelanea(url, headers, bodyRequest, String.class);
        String result = resultMono.block();

        // Assert
        assertEquals(expectedResponse, result);
    }

    @Test
    void shouldThrowBusinessExceptionForHttp422() {
        // Arrange
        String url = "http://test-url.com";
        Map<String, String> headers = Map.of("Operation", "testOperation");
        Object bodyRequest = new Object();

        Mockito.when(webClient.put()).thenReturn(requestBodyUriSpec);
        Mockito.when(requestBodyUriSpec.uri(url)).thenReturn(requestBodySpec);
        Mockito.when(requestBodySpec.header(Mockito.anyString(), Mockito.anyString())).thenReturn(requestBodySpec);
        Mockito.when(requestBodySpec.body(Mockito.any(Mono.class), Mockito.eq(Object.class))).thenReturn(requestHeadersSpec);
        Mockito.when(requestHeadersSpec.exchangeToMono(Mockito.any()))
                .thenAnswer(invocation -> {
                    Function<ClientResponse, Mono<ResponseEntity<String>>> responseFunction = invocation.getArgument(0);
                    ClientResponse mockResponse = ClientResponse.create(HttpStatus.UNPROCESSABLE_ENTITY).build();
                    return responseFunction.apply(mockResponse);
                });

        // Act & Assert
        BusinessException exception = assertThrows(
                BusinessException.class,
                () -> restConsumer.crearMiscelanea(url, headers, bodyRequest, String.class).block()
        );
        assertEquals("Identificación del sistema fuente no válido o no matriculado", exception.getMessage());
    }

    @Test
    void shouldThrowSystemExceptionForUnknownHttpStatus() {
        // Arrange
        String url = "http://test-url.com";
        Map<String, String> headers = Map.of("Operation", "testOperation");
        Object bodyRequest = new Object();

        Mockito.when(webClient.put()).thenReturn(requestBodyUriSpec);
        Mockito.when(requestBodyUriSpec.uri(url)).thenReturn(requestBodySpec);
        Mockito.when(requestBodySpec.header(Mockito.anyString(), Mockito.anyString())).thenReturn(requestBodySpec);
        Mockito.when(requestBodySpec.body(Mockito.any(Mono.class), Mockito.eq(Object.class))).thenReturn(requestHeadersSpec);
        Mockito.when(requestHeadersSpec.exchangeToMono(Mockito.any()))
                .thenAnswer(invocation -> {
                    Function<ClientResponse, Mono<ResponseEntity<String>>> responseFunction = invocation.getArgument(0);
                    ClientResponse mockResponse = ClientResponse.create(HttpStatus.INTERNAL_SERVER_ERROR).build();
                    return responseFunction.apply(mockResponse);
                });

        // Act & Assert
        SystemException exception = assertThrows(
                SystemException.class,
                () -> restConsumer.crearMiscelanea(url, headers, bodyRequest, String.class).block()
        );
        assertEquals("Ha ocurrido un error interno controlado en el servidor", exception.getMessage());
    }

    @Test
    void shouldThrowBusinessExceptionForHttp404() {
        // Arrange
        String url = "http://test-url.com";
        Map<String, String> headers = Map.of("Operation", "key");
        Object bodyRequest = new Object();

        Mockito.when(webClient.put()).thenReturn(requestBodyUriSpec);
        Mockito.when(requestBodyUriSpec.uri(url)).thenReturn(requestBodySpec);
        Mockito.when(requestBodySpec.header(Mockito.anyString(), Mockito.anyString())).thenReturn(requestBodySpec);
        Mockito.when(requestBodySpec.body(Mockito.any(Mono.class), Mockito.eq(Object.class))).thenReturn(requestHeadersSpec);
        Mockito.when(requestHeadersSpec.exchangeToMono(Mockito.any()))
                .thenAnswer(invocation -> {
                    Function<ClientResponse, Mono<ResponseEntity<Object>>> responseFunction = invocation.getArgument(0);
                    ClientResponse mockResponse = ClientResponse.create(HttpStatus.NOT_FOUND).build();
                    return responseFunction.apply(mockResponse);
                });

        // Act & Assert
        Mono<Object> resultMono = restConsumer.crearMiscelanea(url, headers, bodyRequest, Object.class);
        BusinessException exception = assertThrows(BusinessException.class, resultMono::block);
        assertEquals("Cliente no existe", exception.getMessage());
    }

}
