package co.com.bancolombia.api;

import co.com.bancolombia.api.config.JwtGenerator;
import co.com.bancolombia.api.dto.common.Meta;
import co.com.bancolombia.api.dto.response.CustomerRes;
import co.com.bancolombia.api.properties.Params;
import co.com.bancolombia.api.dto.request.DataMisceReq;
import co.com.bancolombia.api.dto.response.DataMisceRes;
import co.com.bancolombia.api.dto.response.DataRes;
import co.com.bancolombia.api.utils.MapperUtils;
import co.com.bancolombia.api.validator.ObjectValidators;
import co.com.bancolombia.consumer.request.Miscellanea_Req;
import co.com.bancolombia.consumer.response.Miscellanea_Res;
import co.com.bancolombia.loggingadapter.KafkaLogEventService;
import co.com.bancolombia.model.createmiscellaneas.exceptions.SecurityException;
import co.com.bancolombia.model.createmiscellaneas.exceptions.messages.SecurityErrorMessage;
import co.com.bancolombia.model.createmiscellaneas.miscellanea.managementMiscellanea.ManagementMisce;
import co.com.bancolombia.policymanager.PolicyManagerService;
import co.com.bancolombia.usecase.datamanagement.DataManagementUseCase;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Mono;

import java.time.ZonedDateTime;
import java.util.HashMap;
import java.util.Map;

@Component
public class Handler {

    private final DataManagementUseCase dataManagementUseCase;
    private final PolicyManagerService policyManagerService;

    private final ObjectValidators objectValidators;

    private final KafkaLogEventService loggingAdapterService;

    private static final String ID_CONSUMER = "id-consumer";

    private final String policyNameSpace;
    private final String policyOperation;

    private static final String MESSAGE_ID = "message-id";

    private final Params params;
    private final JwtGenerator jwtGenerator;

    private final MapperUtils mapperUtils;

    // Constructor para inyectar dependencias
    public Handler(
            DataManagementUseCase dataManagementUseCase,
            PolicyManagerService policyManagerService, ObjectValidators objectValidators, KafkaLogEventService loggingAdapterService,
            @Value("${service.internal.policy-manager.name-space}") String policyNameSpace,
            @Value("${service.internal.policy-manager.operation}") String policyOperation,
            Params params, JwtGenerator jwtGenerator, MapperUtils mapperUtils) {
        this.dataManagementUseCase = dataManagementUseCase;
        this.policyManagerService = policyManagerService;
        this.objectValidators = objectValidators;
        this.policyNameSpace = policyNameSpace;
        this.policyOperation = policyOperation;
        this.params = params;
        this.jwtGenerator = jwtGenerator;
        this.loggingAdapterService=loggingAdapterService;
        this.mapperUtils=mapperUtils;
    }

    public Mono<ServerResponse> createMiscellaneas(ServerRequest serverRequest) {

        String tokenGestionMisce = jwtGenerator.jwtGenerator(
                params.SUB_MISCE,
                params.ISS_MISCE,
                params.CLIENT_MISCE,
                params.SCOPE_MISCE,
                params.TYP
        );

        Map<String, String> headers = new HashMap<>();
        headers.put("Content-Type", "application/json");
        headers.put("Authorization", "Bearer " + tokenGestionMisce);
        headers.put("Operation", "miscelanea");

        
        return serverRequest.bodyToMono(DataMisceReq.class)
                .doOnNext(request -> loggingAdapterService.logHttpRequest(serverRequest, request).subscribe())
                .doOnNext(objectValidators::validate)
                .filterWhen(check -> policyManagerService.verifyConsumer(
                        policyNameSpace,
                        serverRequest.headers().firstHeader(ID_CONSUMER),
                        policyOperation,
                        serverRequest.headers().firstHeader(MESSAGE_ID)
                ))
                .switchIfEmpty(Mono.error(() -> new SecurityException(SecurityErrorMessage.CONSUMER_NOT_ALLOWED)))
                .map(mapperUtils::toDomain)
                .map(request -> {
                    if ("PUT".equalsIgnoreCase(serverRequest.methodName())) {
                        return mapRequestPut(request);
                    } else {
                        return mapRequestPost(request);
                    }
                })
                .flatMap(req -> dataManagementUseCase.crearMiscelanea(params.URI_MISCE, headers, req, Miscellanea_Res.class))
                .map(csr -> dataMisceRes((Miscellanea_Res) csr, serverRequest))
                .flatMap(response -> ServerResponse.status(201).contentType(MediaType.APPLICATION_JSON).bodyValue(response))
                .doOnNext(rs -> loggingAdapterService.logHttpResponse(serverRequest, rs, 200).subscribe())
                .doOnError(error -> System.err.println("Error occurred: " + error.toString()));
    }

    private DataMisceRes dataMisceRes(Miscellanea_Res crs, ServerRequest serverRequest) {


        ZonedDateTime responseDate = ZonedDateTime.now();
        var headers = serverRequest.headers();
        return DataMisceRes.builder()
                .meta(Meta.builder()
                        .requestDateTime(responseDate)
                        .application(headers.firstHeader("application-id"))
                        .messageId(headers.firstHeader(MESSAGE_ID))
                        .build())
                .data(DataRes.builder()
                        .customer(CustomerRes.builder()
                                .sourceSystemCustomerKey(crs.getPkeySrcObject().split("\\|")[0].trim())
                                .sourceSystemID(crs.getRowidSystem().trim())
                                .build())
                        .build())
                .build();
    }

    public Miscellanea_Req mapRequestPost(ManagementMisce managementMisce) {

        return Miscellanea_Req.builder()
                .tipoOperacion("C")
                .pkeySrcObject(managementMisce.getData().getMiscellanea().getSourceSystemCustomerKey())
                .rowidSystem(managementMisce.getData().getMiscellanea().getSourceSystemID())
                .categoriaMiscelanea(managementMisce.getData().getMiscellanea().getMiscellaneaCategory())
                .valorMiscelanea(managementMisce.getData().getMiscellanea().getValue())
                .consecutivoMiscelanea(managementMisce.getData().getMiscellanea().getConsecutive())
                .build();
    }

    public Miscellanea_Req mapRequestPut(ManagementMisce managementMisce) {

        return Miscellanea_Req.builder()
                .tipoOperacion("A")
                .pkeySrcObject(managementMisce.getData().getMiscellanea().getSourceSystemCustomerKey())
                .rowidSystem(managementMisce.getData().getMiscellanea().getSourceSystemID())
                .categoriaMiscelanea(managementMisce.getData().getMiscellanea().getMiscellaneaCategory())
                .valorMiscelanea(managementMisce.getData().getMiscellanea().getValue())
                .consecutivoMiscelanea(managementMisce.getData().getMiscellanea().getConsecutive())
                .build();
    }

    public Mono<ServerResponse> listenGETOtherUseCase(ServerRequest serverRequest) {
        return ServerResponse.ok().body("", String.class);
    }
}