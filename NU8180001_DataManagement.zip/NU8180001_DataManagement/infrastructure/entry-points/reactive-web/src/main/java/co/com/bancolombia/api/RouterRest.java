package co.com.bancolombia.api;

import co.com.bancolombia.api.properties.Params;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.ServerResponse;

import static org.springframework.web.reactive.function.server.RouterFunctions.route;
import static org.springframework.web.reactive.function.server.RequestPredicates.*;


@Configuration
public class RouterRest {
    @Autowired
    private Params params;
@Bean
public RouterFunction<ServerResponse> routerFunction(Handler handler) {
    return route(POST(params.BASE_PATH+params.SERVICE_PATH), handler::createMiscellaneas)
            .and(route(PUT(params.BASE_PATH+params.SERVICE_PATH), handler::createMiscellaneas))
            .and(route(GET("/ping"), handler::listenGETOtherUseCase));
    }
}
