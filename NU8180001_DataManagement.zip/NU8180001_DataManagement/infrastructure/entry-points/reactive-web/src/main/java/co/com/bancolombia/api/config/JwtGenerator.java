package co.com.bancolombia.api.config;

import co.com.bancolombia.consumer.config.InternalConsumer;
import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import org.springframework.stereotype.Component;

import java.security.KeyFactory;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import java.util.Date;
import java.util.Map;

@Component
@RequiredArgsConstructor
public class JwtGenerator {

    private final InternalConsumer internalConsumer;


    @SneakyThrows
    public String jwtGenerator(String sub, String iss, String clientId, String scope, String typ){


        String privateKeyPEM = internalConsumer.getCerprivate();

        String publicKeyPEM = internalConsumer.getCerpublic();


        // Convertir claves de PEM a RSAPrivateKey y RSAPublicKey
        RSAPrivateKey privateKey = getPrivateKeyFromPEM(privateKeyPEM);
        RSAPublicKey publicKey = getPublicKeyFromPEM(publicKeyPEM);

        // Crear el algoritmo RS256
        Algorithm algorithm = Algorithm.RSA256(publicKey, privateKey);

        // Configurar tiempos: iat (emitido en) y exp (expiración)
        long currentTimeMillis = System.currentTimeMillis();
        Date issuedAt = new Date(currentTimeMillis); // Tiempo actual
        Date expiration = new Date(currentTimeMillis + (15 * 1000)); // +15 segundos de validez
        // Generar el token
        String token = JWT.create()
                .withHeader(Map.of(
                        "alg", "RS256",
                        "typ", typ
                ))
                .withSubject(sub)
                .withIssuer(iss)
                .withIssuedAt(issuedAt)  // Claim iat
                .withExpiresAt(expiration) // Claim exp
                .withClaim("token_use", "access")
                .withClaim("client_id", clientId)
                .withClaim("scope", scope)
                .sign(algorithm);

        return token;
    }

    private static RSAPrivateKey getPrivateKeyFromPEM(String key) throws Exception {
        String cleanKey = key
                .replace("-----BEGIN PRIVATE KEY-----", "")
                .replace("-----END PRIVATE KEY-----", "")
                .replaceAll("\\s+", "");

        byte[] decoded = Base64.getDecoder().decode(cleanKey);
        PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(decoded);
        KeyFactory kf = KeyFactory.getInstance("RSA");
        return (RSAPrivateKey) kf.generatePrivate(spec);
    }

    private static RSAPublicKey getPublicKeyFromPEM(String key) throws Exception {

        // Eliminar encabezados, pies de página y saltos de línea
        String cleanKey = key
                .replace("-----BEGIN PUBLIC KEY-----", "")
                .replace("-----END PUBLIC KEY-----", "")
                .replaceAll("\\s+", ""); // Eliminar todos los saltos de línea y espacios

        byte[] decoded = Base64.getDecoder().decode(cleanKey);
        X509EncodedKeySpec spec = new X509EncodedKeySpec(decoded);
        KeyFactory kf = KeyFactory.getInstance("RSA");
        return (RSAPublicKey) kf.generatePublic(spec);
    }
}
