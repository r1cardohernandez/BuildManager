package co.com.bancolombia.api.dto.error;

import co.com.bancolombia.api.dto.common.Meta;
import lombok.Getter;
import lombok.Setter;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Builder;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ErrorRs {

    private Meta meta;
    private int status;
    private String title;
    private List<Error> errors;
}
