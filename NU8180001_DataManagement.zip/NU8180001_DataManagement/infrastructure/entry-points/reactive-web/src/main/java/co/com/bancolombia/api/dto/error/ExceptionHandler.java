package co.com.bancolombia.api.dto.error;


import co.com.bancolombia.api.dto.common.Meta;
import co.com.bancolombia.api.validator.ObjectValidationExceptions;
import co.com.bancolombia.loggingadapter.KafkaLogEventService;
import co.com.bancolombia.model.createmiscellaneas.exceptions.BusinessException;
import co.com.bancolombia.model.createmiscellaneas.exceptions.SystemException;
import co.com.bancolombia.model.createmiscellaneas.exceptions.SecurityException;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.web.WebProperties;
import org.springframework.boot.autoconfigure.web.reactive.error.AbstractErrorWebExceptionHandler;
import org.springframework.boot.web.reactive.error.ErrorAttributes;
import org.springframework.context.ApplicationContext;
import org.springframework.core.annotation.Order;
import org.springframework.http.codec.ServerCodecConfigurer;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.*;
import reactor.core.publisher.Mono;

import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

@Component
@Slf4j
@Order(-2)
public class ExceptionHandler extends AbstractErrorWebExceptionHandler {


    private static final String MESSAGE_ID = "message-id";
    private static final String APPLICATION_ID = "application-id";

    private static final String CONSUMER_ID = "consumer-id";

    private final KafkaLogEventService loggingAdapter;


    public ExceptionHandler(ErrorAttributes errorAttributes, WebProperties resources, ApplicationContext applicationContext, ServerCodecConfigurer serverCodecConfigurer, KafkaLogEventService loggingAdapter) {
        super(errorAttributes, resources.getResources(), applicationContext);
        this.loggingAdapter = loggingAdapter;

        this.setMessageWriters(serverCodecConfigurer.getWriters());
    }

    @Override
    protected RouterFunction<ServerResponse> getRoutingFunction(ErrorAttributes errorAttributes) {
        return RouterFunctions.route(RequestPredicates.all(), this::renderErrorMessage);
    }

    @SneakyThrows
    private Mono<ServerResponse> renderErrorMessage(ServerRequest serverRequest) {



        ZonedDateTime date = ZonedDateTime.now();



        return Mono.error(getError(serverRequest))
                .onErrorResume(ObjectValidationExceptions.class, error -> {
                    log.error("ObjectValidationException", error);

                    List<Error> errorList = error.getErrorList().stream()
                            .map(item -> Error.builder()
                                    .code("SA400")
                                    .detail(item.getDetail())
                                    .build()).toList();

                    ErrorRs rs = ErrorRs.builder()
                            .title("Bad Request")
                            .errors(errorList)
                            .status(400)
                            .meta(Meta.builder()
                                    .messageId(serverRequest.headers().firstHeader("message-id"))
                                    .application(serverRequest.headers().firstHeader("application-id"))
                                    .requestDateTime(date)
                                    .build())
                            .build();

                    return ServerResponse.status(400).bodyValue(rs);
                }).onErrorResume(BusinessException.class, error -> {
                    log.warn("BussinessException", error);
                    List<Error> errorList = new ArrayList<>();

                    int status =  error.getBusinessErrorMessage().getStatus();
                    errorList.add(Error.builder()
                            .code(error.getBusinessErrorMessage().getCode())
                            .detail(error.getBusinessErrorMessage().getMessage())
                            .build());

                    ErrorRs rs = ErrorRs.builder()
                            .title(error.getBusinessErrorMessage().getTitle())
                            .errors(errorList)
                            .status(status)
                            .meta(Meta.builder()
                                    .messageId(serverRequest.headers().firstHeader("message-id"))
                                    .application(serverRequest.headers().firstHeader("application-id"))
                                    .requestDateTime(date)
                                    .build())
                            .build();

                    loggingAdapter.logHttpError(serverRequest, rs, rs.getStatus(), error).subscribe();

                    return ServerResponse
                            .status(status)
                            .bodyValue(rs);

                }).onErrorResume(SecurityException.class, error -> {
                    log.warn("SecurityException", error);
                    List<Error> errorList = new ArrayList<>();

                    errorList.add(Error.builder()
                            .code( error.getSecurityErrorMessage().getCode())
                            .detail(error.getSecurityErrorMessage().getMessage())
                            .build());

                    ErrorRs rs = ErrorRs.builder()
                            .title(error.getSecurityErrorMessage().getTitle())
                            .errors(errorList)
                            .status(error.getSecurityErrorMessage().getStatus())
                            .meta(Meta.builder()
                                    .messageId(serverRequest.headers().firstHeader("message-id"))
                                    .application(serverRequest.headers().firstHeader("application-id"))
                                    .requestDateTime(date)
                                    .build())
                            .build();

                    loggingAdapter.logHttpError(serverRequest, rs, rs.getStatus(), error).subscribe();


                    return ServerResponse
                            .status(error.getSecurityErrorMessage() != null ? error.getSecurityErrorMessage().getStatus() : 500 )
                            .bodyValue(rs);

                }).onErrorResume(SystemException.class, error -> {
                    log.warn("SystemException", error);
                    List<Error> errorList = new ArrayList<>();

                    int status =  error.getSystemErrorMessage().getStatus();
                    errorList.add(Error.builder()
                            .code(error.getSystemErrorMessage().getCode())
                            .detail(error.getSystemErrorMessage().getMessage())
                            .build());

                    ErrorRs rs = ErrorRs.builder()
                            .title(error.getSystemErrorMessage().getTitle())
                            .errors(errorList)
                            .status(status)
                            .meta(Meta.builder()
                                    .messageId(serverRequest.headers().firstHeader("message-id"))
                                    .application(serverRequest.headers().firstHeader("application-id"))
                                    .requestDateTime(date)
                                    .build())
                            .build();

                    loggingAdapter.logHttpError(serverRequest, rs, rs.getStatus(), error).subscribe();

                    return ServerResponse
                            .status(status)
                            .bodyValue(rs);

                }).onErrorResume(NullPointerException.class, error -> {
                    log.error("Bussiness Error", error);

                    List<Error> errorList = new ArrayList<>();


                    return getInternalError(serverRequest, date, errorList);

                })
                .onErrorResume(Exception.class, error -> {
                    log.error("Not controlled exeption", error);
                    List<Error> errorList = new ArrayList<>();

                    return getInternalError(serverRequest, date, errorList);
                })
                .cast(ServerResponse.class);
    }

    private Mono<?> getInternalError(ServerRequest serverRequest, ZonedDateTime date, List<Error> errorList) {
        int status =  500;
        errorList.add(Error.builder()
                .code("SP500")
                .detail("Error en homologacion, request, response, transformacion, error respuesta back")
                .build());

        ErrorRs rs = ErrorRs.builder()
                .title("Internal Server Error")
                .errors(errorList)
                .status(status)
                .meta(Meta.builder()
                        .messageId(serverRequest.headers().firstHeader(MESSAGE_ID))
                        .application(serverRequest.headers().firstHeader(APPLICATION_ID))
                        .requestDateTime(date)
                        .build())
                .build();
        return ServerResponse
                .status(status)
                .bodyValue(rs);
    }



}

