package co.com.bancolombia.api.dto.request;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString
public class DataMisceReq {

    @NotNull(message = "Data no puede estar vacio")
    @Valid
    private DataReq data;

}
