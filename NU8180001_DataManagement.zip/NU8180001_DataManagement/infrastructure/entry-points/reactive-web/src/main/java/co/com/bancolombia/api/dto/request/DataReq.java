package co.com.bancolombia.api.dto.request;


import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder(toBuilder = true)
@ToString

public class DataReq {

    @NotNull(message = "miscellanea no puede ser nulo")
    @Valid
    private Miscellanea miscellanea;


}
