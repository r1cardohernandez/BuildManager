package co.com.bancolombia.api.dto.request;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@ToString
public class Miscellanea {

    @NotNull(message = "sourceSystemID no puede ser nulo")
    @NotBlank(message = "sourceSystemID no puede estar vacio")
    @Size(min = 1, max = 20, message = "sourceSystemID debe tener entre {min} y {max} caracteres")
    @Valid
    private String sourceSystemID;

    @NotNull(message = "sourceSystemCustomerKey no puede ser nulo")
    @NotBlank(message = "sourceSystemCustomerKey no puede estar vacio")
    @Size(min = 1, max = 255, message = "sourceSystemCustomerKey debe tener entre {min} y {max} caracteres")
    @Valid
    private String sourceSystemCustomerKey;

    @NotNull(message = "miscellaneaCategory no puede ser nulo")
    @NotBlank(message = "miscellaneaCategory no puede estar vacio")
    @Size(min = 1, max = 255, message = "miscellaneaCategory debe tener entre {min} y {max} caracteres")
    @Valid
    private String miscellaneaCategory;

    @NotNull(message = "value no puede ser nulo")
    @NotBlank(message = "value no puede estar vacio")
    @Size(min = 1, max = 255, message = "value debe tener entre {min} y {max} caracteres")
    @Valid
    private String value;

    @NotNull(message = "consecutive no puede ser nulo")
    @NotBlank(message = "consecutive no puede estar vacio")
    @Size(min = 1, max = 3, message = "consecutive debe tener entre {min} y {max} caracteres")
    @Valid
    private String consecutive;
}