package co.com.bancolombia.api.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@ToString
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class CustomerRes {

    private String sourceSystemCustomerKey;
    private String sourceSystemID;
}
