package co.com.bancolombia.api.dto.response;

import co.com.bancolombia.api.dto.common.Meta;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)

public class DataMisceRes {
    @JsonProperty("meta")
    private Meta meta;
    @JsonProperty("data")
    private DataRes data;
}
