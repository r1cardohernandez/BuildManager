package co.com.bancolombia.api.properties;

import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Getter
@Setter
@Component
public class Params {
    @Value("${service.base_path}")
    public String BASE_PATH;
    @Value("${service.service_path}")
    public String SERVICE_PATH;
    @Value("${service.service_desc}")
    public  String SERVICE_DESC;
    @Value("${service.service_name}")
    public  String SERVICE_NAME;
    @Value("${service.content_type}")
    public  String CONTENT_TYPE_JSON;
    @Value("${service.message_id}")
    public String MESSAGE_ID_D;
    @Value("${service.service_operation}")
    public String SERVICE_OPERATION;
    @Value("${service.service_namespace}")
    public String SERVICE_NAMESPACE;
    @Value("${service.id_consumer}")
    public String ID_CONSUMER;

    @Value("${service.url_misce}")
    public String URI_MISCE;

    @Value("${service.typ}")
    public String TYP;

    @Value("${service.sub_misce}")
    public String SUB_MISCE;

    @Value("${service.iss_misce}")
    public String ISS_MISCE;

    @Value("${service.client_misce}")
    public String CLIENT_MISCE;

    @Value("${service.scope_misce}")
    public String SCOPE_MISCE;
}
