package co.com.bancolombia.api.utils;

import co.com.bancolombia.api.dto.request.DataMisceReq;
import co.com.bancolombia.model.createmiscellaneas.miscellanea.managementMiscellanea.ManagementMisce;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;
import org.springframework.stereotype.Component;

@Mapper(componentModel = "spring")
public interface MapperUtils {
    MapperUtils INSTANCE = Mappers.getMapper(MapperUtils.class);
    ManagementMisce toDomain(DataMisceReq dataMisceReq);

}