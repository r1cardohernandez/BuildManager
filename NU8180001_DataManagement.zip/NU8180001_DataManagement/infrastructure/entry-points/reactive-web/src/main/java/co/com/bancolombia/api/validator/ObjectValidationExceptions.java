package co.com.bancolombia.api.validator;

import co.com.bancolombia.api.dto.error.Error;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class ObjectValidationExceptions extends RuntimeException {

    private final transient List<Error> errorList;

    public ObjectValidationExceptions(List<Error> errors) {
        super("Please supply the valid data: " + errors);
        errorList = errors;
    }

}
