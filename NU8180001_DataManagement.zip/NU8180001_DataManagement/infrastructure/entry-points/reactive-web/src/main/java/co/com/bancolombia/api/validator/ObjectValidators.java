package co.com.bancolombia.api.validator;

import co.com.bancolombia.api.dto.error.Error;
import jakarta.validation.Validator;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@RequiredArgsConstructor
public class ObjectValidators {

    private final Validator validator;

    public <T> T validate(T object) {
        var errors = validator.validate(object);
        if (errors.isEmpty()) {
            return object;
        } else {
            List<Error> listErrors = errors.stream().map(tConstraintViolation -> Error.builder()
                    .detail(tConstraintViolation.getMessage())
                    .build()).toList();

            throw new ObjectValidationExceptions(listErrors);
        }
    }
}

