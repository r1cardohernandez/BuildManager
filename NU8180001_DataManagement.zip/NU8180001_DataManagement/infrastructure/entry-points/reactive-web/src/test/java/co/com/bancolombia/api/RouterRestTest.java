package co.com.bancolombia.api;

import co.com.bancolombia.api.config.JwtGenerator;
import co.com.bancolombia.api.utils.MapperUtils;
import co.com.bancolombia.api.validator.ObjectValidators;
import co.com.bancolombia.api.properties.Params;
import co.com.bancolombia.consumer.response.Miscellanea_Res;
import co.com.bancolombia.loggingadapter.KafkaLogEventService;
import co.com.bancolombia.model.createmiscellaneas.exceptions.BusinessException;
import co.com.bancolombia.model.createmiscellaneas.exceptions.messages.BusinessErrorMessage;
import co.com.bancolombia.model.createmiscellaneas.miscellanea.Miscellanea;
import co.com.bancolombia.model.createmiscellaneas.miscellanea.managementMiscellanea.Data;
import co.com.bancolombia.model.createmiscellaneas.miscellanea.managementMiscellanea.ManagementMisce;
import co.com.bancolombia.policymanager.PolicyManagerService;
import co.com.bancolombia.usecase.datamanagement.DataManagementUseCase;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.web.reactive.function.server.ServerRequest;
import reactor.core.publisher.Mono;


import java.net.URI;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ContextConfiguration(classes = {RouterRest.class, Handler.class, Params.class, JwtGenerator.class, ObjectValidators.class})
@WebFluxTest

public class RouterRestTest {

    @Autowired
    private WebTestClient webTestClient;

    @MockBean
    private DataManagementUseCase dataManagementUseCase;

    @MockBean
    private PolicyManagerService policyManagerService;

    @MockBean
    private KafkaLogEventService loggingAdapterService;

    @MockBean
    private MapperUtils mapperUtils;

    @Autowired
    private Params params;

    @MockBean
    private JwtGenerator jwtGenerator;


    @DynamicPropertySource
    static void dynamicProperties(DynamicPropertyRegistry registry) {
        registry.add("service.base_path", () -> "/mdm-integracion/v1/sales-service/customer-management/customer-miscellanea-management/data-management");
        registry.add("service.service_path", () -> "/miscellaneas");
        registry.add("service.jwt.token.lifetime", () -> "54000");
        registry.add("service.jwt.token.enable_lifetime", () -> "false");
    }

    private String validRequest() {
        return  "{\n" +
                "   \"data\": {\n" +
                "       \"miscellanea\": {\n" +
                "           \"sourceSystemID\": \"CIF\",\n" +
                "           \"sourceSystemCustomerKey\": \"160811151026001\",\n" +
                "           \"miscellaneaCategory\": \"MASCOTA\",\n" +
                "           \"value\": \"FIRULAISIII\",\n" +
                "           \"consecutive\": \"1\"\n" +
                "       }\n" +
                "   }\n" +
                "}";
    }

    private ManagementMisce validRequest1(String sourceSystemID, String sourceSystemCustomerKey, String miscellaneaCategory, String value, String consecutive) {
        return ManagementMisce.builder()
                .data(Data.builder()
                        .miscellanea(Miscellanea.builder()
                                .sourceSystemID(sourceSystemID)
                                .sourceSystemCustomerKey(sourceSystemCustomerKey)
                                .miscellaneaCategory(miscellaneaCategory)
                                .value(value)
                                .consecutive(consecutive)
                                .build())
                .build())
        .build();

    }

    @Test
    void testCreateInvalidRequestBodies() {
        when(dataManagementUseCase.crearMiscelanea(any(), any(), any(), any()))
                .thenThrow(new BusinessException(BusinessErrorMessage.INVALID_REQUEST));

        when(jwtGenerator.jwtGenerator(any(), any(), any(), any(), any()))
                .thenReturn(getJwtMisce());

        when(policyManagerService.verifyConsumer(any(), any(), any(), any())).thenReturn(Mono.just(true));

        when(loggingAdapterService.logHttpRequest(any(), any())).thenReturn(Mono.empty());
        when(loggingAdapterService.logHttpResponse(any(), any(), any())).thenReturn(Mono.empty());

        when(mapperUtils.toDomain(any())).thenReturn(validRequest1("MDM", "171002111852","MASCOTA","FIRULAIS", "1"));

        webTestClient.post()
                .uri(params.BASE_PATH + params.SERVICE_PATH)
                .header("Content-Type", "application/json")
                .header("message-id", "test-uuid")
                .header("id-consumer", "NU7230001")
                .header("application-id", "ApplicationId321")
                .bodyValue(validRequest())
                .exchange()
                .expectStatus().is5xxServerError() // 500
                .expectBody(String.class)
                .value(userResponse -> Assertions.assertThat(userResponse).contains("Internal Server Error"));
    }

    @ParameterizedTest
    @CsvSource({
            "'{\"data\":{\"miscellanea\":{}}}', 500",
            "'{\"data\":{}}', 500"
    })
    void testInvalidRequestBodies(String requestBody, int status) {
        webTestClient.post()
                .uri(params.BASE_PATH + params.SERVICE_PATH)
                .header("Content-Type", "application/json")
                .header("id-consumer", "AW1820001")
                .header("message-id", "testInvalidBody")
                .header("application-id", "ApplicationId321")
                .bodyValue(requestBody)
                .exchange()
                .expectStatus().isEqualTo(status)
                .expectBody(String.class)
                .value(userResponse -> Assertions.assertThat(userResponse).contains("Internal Server Error"));
    }

    @ParameterizedTest
    @CsvSource({
        "'{\"data\":{\"miscellanea\":{\"consecutive\":\"1\",\"miscellaneaCategory\":\"MUSICA\",\"sourceSystemCustomerKey\":\"160811151026001\",\"sourceSystemID\":\"CIF\",\"value\":\"JAZZ\"}}}', 201"
    })

    void testCreateMiscellaneaSuccess(String requestBody, int status) {
        Miscellanea_Res response = getResponseMiscellanea();

        when(dataManagementUseCase.crearMiscelanea(any(), any(), any(), any()))
                .thenReturn(Mono.just(response));

        when(jwtGenerator.jwtGenerator(any(), any(), any(), any(), any()))
                .thenReturn(getJwtMisce());

        when(policyManagerService.verifyConsumer(any(), any(), any(), any())).thenReturn(Mono.just(true));

        when(loggingAdapterService.logHttpRequest(any(), any())).thenReturn(Mono.empty());
        when(loggingAdapterService.logHttpResponse(any(), any(), any())).thenReturn(Mono.empty());
        when(mapperUtils.toDomain(any())).thenReturn(validRequest1("CIF", "160811151026001","MUSICA","FIRULAIS", "1"));


        webTestClient.post()
                .uri(params.BASE_PATH + params.SERVICE_PATH)
                .header("Content-Type", "application/json")
                .header("message-id", "test-uuid")
                .header("id-consumer", "NU7230001")
                .bodyValue(requestBody)
                .exchange()
                .expectStatus().isEqualTo(status)// 201
                .expectBody(String.class)
                .value(userResponse -> {
                    Assertions.assertThat(userResponse).contains("160811151026001");
                    Assertions.assertThat(userResponse).contains("CIF");
        });
    }

//ping
    @Test
    void testExceptionHandling(){
        when(dataManagementUseCase.crearMiscelanea(any(), any(), any(), any()))
                .thenThrow( new RuntimeException() {});
        when(policyManagerService.verifyConsumer(any(), any(), any(), any())).thenReturn(Mono.just(true));
        when(loggingAdapterService.logHttpRequest(any(), any())).thenReturn(Mono.empty());
        when(loggingAdapterService.logHttpResponse(any(), any(), any())).thenReturn(Mono.empty());

        webTestClient.post()
                .uri(params.BASE_PATH + params.SERVICE_PATH)
                .header("Content-Type", "application/json")
                .header("id-consumer", "AW1074001")
                .header("message-id", "testFailure")
                .header("application-id", "ApplicationId321")
                .bodyValue("{}")
                .exchange()
                .expectStatus().is5xxServerError();  // Espera una respuesta 500 por excepción
    }
    @Test
    void testActualizarMiscellaneaSuccess() {
        Miscellanea_Res response = getResponseMiscellanea();

        when(dataManagementUseCase.crearMiscelanea(any(), any(), any(), any()))
                .thenReturn(Mono.just(response));

        when(jwtGenerator.jwtGenerator(any(), any(), any(), any(), any()))
                .thenReturn(getJwtMisce());

        when(policyManagerService.verifyConsumer(any(), any(), any(), any())).thenReturn(Mono.just(true));

        when(loggingAdapterService.logHttpRequest(any(), any())).thenReturn(Mono.empty());
        when(loggingAdapterService.logHttpResponse(any(), any(), any())).thenReturn(Mono.empty());
        when(mapperUtils.toDomain(any())).thenReturn(validRequest1("CIF", "160811151026001","MUSICA","FIRULAIS", "1"));

        webTestClient.put()
                .uri(params.BASE_PATH + params.SERVICE_PATH)
                .header("Content-Type", "application/json")
                .header("message-id", "test-uuid")
                .header("id-consumer", "NU7230001")
                .bodyValue(validRequest())
                .exchange()
                .expectStatus().isCreated()// 201
                .expectBody(String.class)
                .value(userResponse -> {
                    Assertions.assertThat(userResponse).contains("160811151026001");
                    Assertions.assertThat(userResponse).contains("CIF");
                });
    }




    private String getJwtMisce() {
        return "eyJhbGciOiJSUzI1NiIsInR5cCI6Imd3LWF3cy1la3MtbWRtLWp3dC1kZXYifQ.eyJzdWIiOiJhcGktY29ubmVjdC1hcGktZ2VzdGlvbmNsaWVudGUtcG9kIiwiaXNzIjoiaHR0cHM6Ly9hcGktYXdzLWRldi5hcHBzLmFtYmllbnRlc2JjLmNvbS9nZXN0aW9uY2xpZW50ZSIsInRva2VuX3VzZSI6ImFjY2VzcyIsImNsaWVudF9pZCI6ImFwaS1jb25uZWN0LWFwaS1nZXN0aW9uY2xpZW50ZS1wb2QiLCJzY29wZSI6ImFwaS1nZXN0aW9uY2xpZW50ZS1wb2QifQ.gHLW_pd8MvN30FTYWvr1SEx-tg9790FK8IOZFs8q8wnzW-94Uljv-2Upvq6trPAX3O0y07quBr3nIzuCG5H9TmKjHFAoJmYFs5vHh0bXSqgdmZyD3SlWUF9X_RjXxOuVz1QWCs6lHW5hk3aWIMARNRyLk8aZM7eNsselocjsqr_ZGfp3u6Ovse2q1so2uHThDNY3a6Zc8hPAThTvIOOyu0p8i5P9FUy5UPKYYRIhzlkW2ynhDBke6XKo-fBsr1j4DQcxFfWuDm3rRod4YFISo8bHnKHUuz6ZZIrxl072bhGmib8h2HBVzN0DUJVYX9RjfQA65yv3vCG9OZhQYoZj9w";
    }

    private Miscellanea_Res getResponseMiscellanea() {
        return Miscellanea_Res.builder()
                .rowidSystem("CIF")
                .pkeySrcObject("160811151026001|MUSICA|1")
                .build();
    }
}
